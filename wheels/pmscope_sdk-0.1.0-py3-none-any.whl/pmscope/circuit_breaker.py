"""
Async circuit breaker for PM-SCOPE service fan-out calls.

Optional dependency: purgatory~=3.0.1
If not installed, call_with_breaker passes through directly (no breaking).

Public API:
    await call_with_breaker(service, coro)  -> Any (raises circuit-open exception when open)
    get_all_states()                         -> dict[service_name -> 'open'|'closed'|'half_open']

Env vars (with defaults):
    PMSCOPE_CIRCUIT_FAIL_THRESHOLD = 5    # failures before opening
    PMSCOPE_CIRCUIT_COOLDOWN_SECONDS = 30 # seconds before half-open probe

Note: purgatory 3.0.1 exposes only default_threshold + default_ttl constructor args.
There is no separate counting-window parameter (PMSCOPE_CIRCUIT_WINDOW_SECONDS omitted).

# Discovered exception class names via dir() probe on purgatory 3.0.1
#   purgatory.domain has submodules: messages, model (no 'exceptions' submodule)
#   Circuit-open exception: purgatory.domain.model.OpenedState
#   Full MRO: ['OpenedState', 'State', 'ABC', 'Exception', 'BaseException', 'object']
#   This differs from the research assumption of 'OpenedCircuit' — use OpenedState.
"""
import logging
import os
from typing import Any, Awaitable

logger = logging.getLogger("pmscope.circuit_breaker")

_FAIL_THRESHOLD = int(os.getenv("PMSCOPE_CIRCUIT_FAIL_THRESHOLD", "5"))
_COOLDOWN_SECONDS = int(os.getenv("PMSCOPE_CIRCUIT_COOLDOWN_SECONDS", "30"))

try:
    from purgatory import AsyncCircuitBreakerFactory
    # Confirmed exception class from dir() probe: purgatory.domain.model.OpenedState
    # (NOT purgatory.domain.exceptions.OpenedCircuit — that path does not exist in 3.0.1)
    from purgatory.domain.model import OpenedState as OpenedCircuit  # noqa: N814
    _factory = AsyncCircuitBreakerFactory(
        default_threshold=_FAIL_THRESHOLD,
        default_ttl=_COOLDOWN_SECONDS,
    )
    _PURGATORY_AVAILABLE = True
except ImportError:
    _factory = None
    OpenedCircuit = None  # type: ignore[assignment,misc]
    _PURGATORY_AVAILABLE = False
    logger.warning("purgatory not installed — circuit breaking disabled (passthrough mode)")

# Optional Prometheus — exact pattern from redis_job_store.py lines 26-43
try:
    from prometheus_client import Gauge
    try:
        _CB_OPEN_GAUGE = Gauge(
            "pmscope_circuit_open",
            "1 if circuit breaker is open for service, 0 if closed/half-open",
            ["service"],
        )
    except ValueError:
        # Metric already registered in this process (e.g. test re-import).
        from prometheus_client import REGISTRY
        _CB_OPEN_GAUGE = REGISTRY._names_to_collectors.get("pmscope_circuit_open")
    _PROM_AVAILABLE = True
except ImportError:
    _CB_OPEN_GAUGE = None
    _PROM_AVAILABLE = False


_state_cache: dict[str, str] = {}


def _update_state(service: str, state: str) -> None:
    """Record state transition. CRITICAL log on transitions except initial unknown->closed."""
    prev = _state_cache.get(service)
    _state_cache[service] = state
    # Suppress noisy first-call initialization: unknown->closed is not a real state change.
    # Per Pitfall #5 in 03-RESEARCH.md.
    if prev != state and prev is not None:
        logger.critical("CIRCUIT STATE CHANGE: service=%s %s -> %s", service, prev, state)
    if _CB_OPEN_GAUGE is not None:
        try:
            _CB_OPEN_GAUGE.labels(service=service).set(1 if state == "open" else 0)
        except Exception:
            pass  # never let metrics break the breaker


async def call_with_breaker(service: str, coro: Awaitable[Any]) -> Any:
    """Execute `coro` inside a circuit breaker keyed by service name.

    Args:
        service: stable service identifier (e.g., 'sherlock', 'email-tools') — must match
            the YAML registry key so state lines up across call sites.
        coro: an awaitable (coroutine or httpx coroutine) — caller passes it unawaited.

    Raises:
        OpenedCircuit (purgatory.domain.model.OpenedState): when breaker is open.
            Caller should treat as a service-unavailable signal (return empty/cached,
            do not retry).
        Original exception: passed through unchanged when breaker is closed/half-open.
    """
    if not _PURGATORY_AVAILABLE or _factory is None:
        # Passthrough — no state recording, no metric flips
        return await coro
    breaker = await _factory.get_breaker(service)
    try:
        async with breaker:
            result = await coro
        _update_state(service, "closed")
        return result
    except Exception as exc:
        if OpenedCircuit is not None and isinstance(exc, OpenedCircuit):
            _update_state(service, "open")
            raise
        # Underlying coroutine raised — check if purgatory transitioned to open
        # (happens on the failure that hits the threshold: purgatory opens synchronously
        # but does NOT raise OpenedState for the threshold call itself, only subsequent).
        _sync_state_from_factory(service)
        raise


def _sync_state_from_factory(service: str) -> None:
    """Sync our _state_cache from purgatory's internal context state."""
    if _factory is None:
        return
    try:
        ctx = _factory.uow.contexts.breakers.get(service)
        if ctx is None:
            return
        # purgatory state names: 'closed', 'opened', 'half_opened'
        # Map to our canonical names: 'closed', 'open', 'half_open'
        state_name = str(ctx.state).lower()
        if "opened" in state_name and "half" not in state_name:
            canonical = "open"
        elif "half" in state_name:
            canonical = "half_open"
        else:
            canonical = "closed"
        _update_state(service, canonical)
    except Exception:
        pass  # never let state sync break the caller


def get_all_states() -> dict[str, str]:
    """Return a snapshot of {service: state} for the GET /admin/circuit-status endpoint.

    Returns a copy — mutating the result does NOT affect the internal cache.
    Safe to call before any breaker has ever fired (returns {}).
    """
    return dict(_state_cache)
