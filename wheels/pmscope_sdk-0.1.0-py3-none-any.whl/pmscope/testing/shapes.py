"""Pure-Python contract assertions for wrapper-service responses.

No test framework dependency — these raise plain AssertionError, drop-in
compatible with pytest, unittest, or any custom runner.
"""
from typing import Any


def assert_watchlist_response_shape(response_json: Any) -> None:
    """Verify a /watchlist/scan response matches the canonical shape.

    Raises AssertionError with a descriptive message if any of:
      - response is not a dict
      - missing any of {entities, attributes, mentions, metadata}
      - entities is not a list
      - attributes is not a dict
      - mentions is not a list
      - metadata is not a dict
    """
    assert isinstance(response_json, dict), (
        f"expected dict, got {type(response_json).__name__}"
    )
    for key in ("entities", "attributes", "mentions", "metadata"):
        assert key in response_json, f"missing key: {key!r}"
    assert isinstance(response_json["entities"], list), (
        f"entities must be list, got {type(response_json['entities']).__name__}"
    )
    assert isinstance(response_json["attributes"], dict), (
        f"attributes must be dict, got {type(response_json['attributes']).__name__}"
    )
    assert isinstance(response_json["mentions"], list), (
        f"mentions must be list, got {type(response_json['mentions']).__name__}"
    )
    assert isinstance(response_json["metadata"], dict), (
        f"metadata must be dict, got {type(response_json['metadata']).__name__}"
    )


def assert_health_response_shape(response_json: Any) -> None:
    """Verify a /health response matches the canonical shape.

    Raises AssertionError if any of:
      - response is not a dict
      - status is not one of {healthy, degraded, unhealthy}
      - missing service key
    """
    assert isinstance(response_json, dict), (
        f"expected dict, got {type(response_json).__name__}"
    )
    status = response_json.get("status")
    assert status in ("healthy", "degraded", "unhealthy"), (
        f"invalid status: {status!r} — expected one of healthy/degraded/unhealthy"
    )
    assert "service" in response_json, "missing key: 'service'"


__all__ = ["assert_watchlist_response_shape", "assert_health_response_shape"]
