"""Manifest validation helper for module repo CI."""
from pmscope.manifest import ModuleManifest


def assert_module_manifest_valid(manifest_dict: dict) -> ModuleManifest:
    """Validate a dict against ModuleManifest v1.

    Returns the parsed ModuleManifest on success.
    Raises pydantic.ValidationError on failure (with field-level details).

    Use this in module repo tests:

        import yaml
        from pmscope.testing import assert_module_manifest_valid

        def test_manifest():
            with open("pmscope-module.yaml") as f:
                assert_module_manifest_valid(yaml.safe_load(f))
    """
    return ModuleManifest.model_validate(manifest_dict)


__all__ = ["assert_module_manifest_valid"]
