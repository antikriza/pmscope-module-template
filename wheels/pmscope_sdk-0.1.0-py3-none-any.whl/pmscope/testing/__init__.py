"""PM-SCOPE module contract test helpers.

Pure functions, NOT a pytest plugin. Import directly in module repo tests:

    from pmscope.testing import (
        assert_watchlist_response_shape,
        assert_health_response_shape,
        assert_module_manifest_valid,
    )

Each function asserts contract conformance and raises on mismatch
(AssertionError for shapes, pydantic.ValidationError for manifests).
"""
from pmscope.testing.shapes import (
    assert_watchlist_response_shape,
    assert_health_response_shape,
)
from pmscope.testing.manifests import assert_module_manifest_valid

__all__ = [
    "assert_watchlist_response_shape",
    "assert_health_response_shape",
    "assert_module_manifest_valid",
]
