"""
Redis-backed job store for PM-SCOPE wrapper services.

Replaces the in-memory JobStore with Redis persistence.
Jobs survive service restarts and can be shared between replicas.

Usage:
    from pmscope.redis_job_store import create_job_store
    job_store = create_job_store(redis_url="redis://redis:6379/20", prefix="traffic")
"""

import copy
import json
import time
import threading
from typing import Any, Dict, List, Optional

import logging

import redis

logger = logging.getLogger("pmscope.redis_job_store")

# Optional Prometheus instrumentation — wrapped in try/except so wrapper
# services that don't have prometheus_client installed don't break.
try:
    from prometheus_client import Gauge
    try:
        _REDIS_FALLBACK_GAUGE = Gauge(
            "pmscope_redis_fallback_active",
            "1 if the in-memory job-store fallback is active (data loss on restart), 0 if Redis is healthy",
            ["prefix"],
        )
    except ValueError:
        # Metric already registered in this process (e.g. test re-import).
        from prometheus_client import REGISTRY
        _REDIS_FALLBACK_GAUGE = REGISTRY._names_to_collectors.get(
            "pmscope_redis_fallback_active"
        )
    _PROM_AVAILABLE = True
except ImportError:
    _REDIS_FALLBACK_GAUGE = None
    _PROM_AVAILABLE = False


def _set_fallback_gauge(prefix: str, active: bool) -> None:
    """Flip the Prometheus gauge for a given prefix. Never raises."""
    if _REDIS_FALLBACK_GAUGE is not None:
        try:
            _REDIS_FALLBACK_GAUGE.labels(prefix=prefix).set(1 if active else 0)
        except Exception:
            pass  # never let metrics break the job store

JOB_TTL_SECONDS = 7200  # 2 hours


class RedisJobStore:
    """Redis-backed job store using hashes per job."""

    def __init__(self, redis_url: str, prefix: str = "jobs"):
        self._redis = redis.from_url(redis_url, decode_responses=True)
        self._prefix = prefix

    def _key(self, job_id: str) -> str:
        return f"pmscope:{self._prefix}:job:{job_id}"

    def create_job(self, job_id: str, target: str, target_type: str, **extra) -> None:
        data = {
            "job_id": job_id,
            "status": "queued",
            "target": target,
            "target_type": target_type,
            "error": "",
            "created_at": str(time.time()),
            "started_at": "",
            "completed_at": "",
        }
        # Merge any extra fields (tweets, posts, snapshots, etc.)
        for k, v in extra.items():
            if isinstance(v, (dict, list)):
                data[k] = json.dumps(v)
            elif v is None:
                data[k] = ""
            else:
                data[k] = str(v)

        key = self._key(job_id)
        self._redis.hset(key, mapping=data)
        self._redis.expire(key, JOB_TTL_SECONDS)

    def update_job(self, job_id: str, **kwargs) -> None:
        key = self._key(job_id)
        if not self._redis.exists(key):
            return

        updates = {}
        for k, v in kwargs.items():
            if isinstance(v, (dict, list)):
                updates[k] = json.dumps(v)
            elif v is None:
                updates[k] = ""
            else:
                updates[k] = str(v)

        if updates:
            self._redis.hset(key, mapping=updates)
            self._redis.expire(key, JOB_TTL_SECONDS)

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        key = self._key(job_id)
        data = self._redis.hgetall(key)
        if not data:
            return None
        return self._deserialize(data)

    def list_jobs(self, limit: int = 20) -> List[Dict[str, Any]]:
        pattern = f"pmscope:{self._prefix}:job:*"
        jobs = []
        for key in self._redis.scan_iter(match=pattern, count=100):
            data = self._redis.hgetall(key)
            if data:
                jobs.append(self._deserialize(data))
            if len(jobs) >= limit * 2:
                break
        # Sort by created_at descending
        jobs.sort(key=lambda j: float(j.get("created_at") or 0), reverse=True)
        return jobs[:limit]

    # Fields that must always remain strings (never JSON-parsed).
    # Unknown fields use startswith heuristic for auto-detection.
    _STRING_FIELDS = frozenset({"job_id", "target", "target_type", "status", "error", "domain"})

    @staticmethod
    def _deserialize(data: Dict[str, str]) -> Dict[str, Any]:
        """Convert Redis strings back to appropriate Python types."""
        result = {}
        float_fields = {"created_at", "started_at", "completed_at"}

        for k, v in data.items():
            if v == "":
                result[k] = None
            elif k in float_fields:
                try:
                    result[k] = float(v)
                except (ValueError, TypeError):
                    result[k] = None
            elif k not in RedisJobStore._STRING_FIELDS and v.startswith(("{", "[")):
                try:
                    result[k] = json.loads(v)
                except (json.JSONDecodeError, TypeError):
                    result[k] = v
            else:
                result[k] = v
        return result


class InMemoryJobStore:
    """Fallback in-memory job store (same interface as RedisJobStore)."""

    def __init__(self):
        self._store: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def create_job(self, job_id: str, target: str, target_type: str, **extra) -> None:
        with self._lock:
            cutoff = time.time() - JOB_TTL_SECONDS
            self._store = {k: v for k, v in self._store.items() if (v.get("created_at") or 0) >= cutoff}
            data = {
                "job_id": job_id,
                "status": "queued",
                "target": target,
                "target_type": target_type,
                "error": None,
                "created_at": time.time(),
                "started_at": None,
                "completed_at": None,
            }
            data.update(extra)
            self._store[job_id] = data

    def update_job(self, job_id: str, **kwargs) -> None:
        with self._lock:
            if job_id in self._store:
                self._store[job_id].update(kwargs)

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            job = self._store.get(job_id)
            return copy.deepcopy(job) if job else None

    def list_jobs(self, limit: int = 20) -> List[Dict[str, Any]]:
        with self._lock:
            jobs = sorted(
                self._store.values(),
                key=lambda j: j.get("created_at") or 0,
                reverse=True,
            )
            return [copy.deepcopy(j) for j in jobs[:limit]]


def create_job_store(redis_url: str = "", prefix: str = "jobs"):
    """Create a job store — Redis if available, in-memory fallback (LOUD on fallback)."""
    if redis_url:
        try:
            store = RedisJobStore(redis_url, prefix)
            store._redis.ping()
            logger.info(
                "Redis job store active: prefix=%s, url=%s",
                prefix,
                redis_url.split("@")[-1] if "@" in redis_url else redis_url,
            )
            _set_fallback_gauge(prefix, False)
            return store
        except Exception as exc:
            logger.critical(
                "DATA LOSS RISK: Redis unreachable, using in-memory job store. "
                "Jobs will be lost on restart. prefix=%s error=%s",
                prefix,
                exc,
            )
            _set_fallback_gauge(prefix, True)
    else:
        logger.critical(
            "DATA LOSS RISK: no REDIS_URL configured, using in-memory job store. "
            "Jobs will be lost on restart. prefix=%s",
            prefix,
        )
        _set_fallback_gauge(prefix, True)
    return InMemoryJobStore()
