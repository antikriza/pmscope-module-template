"""PM-SCOPE module manifest schema (v1).

External module repositories declare themselves via a `manifest.yaml` (or
`pmscope.toml`) at their root. This module is the single source of truth
for the v1 schema. Phase 5b will add a loader that reads modules.d/*.yaml
and merges them into services.yaml at runtime; THAT is out of scope here.

Strict mode: extra="forbid" — unknown top-level fields are rejected so we
catch typos in module manifests at validation time rather than at
runtime when Phase 5b's loader silently drops them.
"""
from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class ApiKeyRequirement(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    source: Literal["env", "vault"] = "env"
    required: bool = True


class ModuleManifest(BaseModel):
    """v1 PM-SCOPE module manifest.

    Either `docker_image` (production) OR `build_context` (local dev) must
    be specified — never both, never neither.
    """
    model_config = ConfigDict(extra="forbid")

    manifest_version: Literal[1] = 1

    # Identity (slug-style names: lowercase, hyphens, must start with letter)
    name: str = Field(pattern=r"^[a-z][a-z0-9-]*$")
    display_name: str
    version: str = Field(pattern=r"^\d+\.\d+\.\d+(-[a-zA-Z0-9.]+)?$")
    description: Optional[str] = None

    # Deployment — exactly one of docker_image OR build_context
    docker_image: Optional[str] = None   # must be @sha256-pinned for production
    build_context: Optional[str] = None  # local dev only

    # Compatibility
    sdk_version: str = ">=0.1,<0.2"

    # Watchlist integration
    entity_types: List[str] = Field(default_factory=list)
    watchlist_severity: Literal["low", "medium", "high", "critical"] = "medium"

    # Chat integration
    chat_command: Optional[str] = None        # MUST start with /
    chat_usage: Optional[str] = None
    chat_description: Optional[str] = None

    # Configuration
    api_keys_required: List[ApiKeyRequirement] = Field(default_factory=list)

    # Lifecycle
    deprecated: bool = False

    @field_validator("docker_image")
    @classmethod
    def must_be_digest_pinned_or_none(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        if "@sha256:" in v:
            return v
        raise ValueError(
            f"docker_image must be digest-pinned with @sha256:... (got: {v!r}). "
            "For local dev use build_context instead."
        )

    @field_validator("chat_command")
    @classmethod
    def must_start_with_slash(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and not v.startswith("/"):
            raise ValueError(f"chat_command must start with /, got: {v!r}")
        return v

    @model_validator(mode="after")
    def check_image_or_build_context(self) -> "ModuleManifest":
        if not self.docker_image and not self.build_context:
            raise ValueError(
                "Must specify either docker_image (production) or "
                "build_context (local dev)"
            )
        if self.docker_image and self.build_context:
            raise ValueError(
                "Cannot specify both docker_image and build_context — pick one"
            )
        return self


__all__ = ["ModuleManifest", "ApiKeyRequirement"]
