# PM-SCOPE shared library — intra-service auth + Redis job store
from pmscope.base_wrapper import build_wrapper_app  # noqa: F401

try:
    from pmscope.manifest import ModuleManifest, ApiKeyRequirement  # noqa: F401
except ImportError:
    # pydantic may not be available in lightweight contexts (e.g., the
    # base_wrapper-only consumer). Fail soft.
    pass

# Re-export testing helpers so consumers can do `from pmscope import testing`.
# The submodule itself imports from pmscope.manifest, so it inherits the same
# try/except guard at runtime — explicit import ensures clear error if pydantic
# is missing (vs. silent skip).
try:
    from pmscope import testing  # noqa: F401
except ImportError:
    pass

# AuditBuffer for module-side batched audit flushing (REQ-08).
# httpx is a hard dep in pyproject.toml, but lib/ may be imported directly
# without install in lightweight contexts — fail soft to keep base SDK usable.
try:
    from pmscope.audit_buffer import AuditBuffer, AuditEvent  # noqa: F401
except ImportError:
    pass
