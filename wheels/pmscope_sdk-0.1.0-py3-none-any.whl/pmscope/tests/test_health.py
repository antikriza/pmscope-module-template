"""Tests for pmscope.health — build_deep_health envelope helper.

Covers the contract that the 28 wrapper services rely on:
    * envelope shape is stable (service, verdict, checked_at, duration_ms,
      probes[], required_failed, optional_failed)
    * probes run in parallel (N probes ≈ max(durations), not sum)
    * per-probe timeout is enforced and captured as fail without raising
    * a misbehaving probe (exception, malformed return) degrades to fail
    * overall verdict aggregates: any fail → fail, any warn → warn, else pass
    * empty probe list → warn with a "no probes" detail
"""
from __future__ import annotations

import asyncio
import os
import sys
import time

import pytest

# Ensure lib/ is importable even when tests are run from repo root.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from pmscope.health import build_deep_health  # noqa: E402


# ─── Envelope shape ──────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_envelope_shape_with_single_probe():
    async def ok():
        return "pass"

    env = await build_deep_health("sherlock", [ok])

    # All contract keys present.
    for key in (
        "service",
        "verdict",
        "checked_at",
        "duration_ms",
        "probes",
        "required_failed",
        "optional_failed",
    ):
        assert key in env, f"envelope missing {key!r}"

    assert env["service"] == "sherlock"
    assert env["verdict"] == "pass"
    assert env["required_failed"] == 0
    assert env["optional_failed"] == 0
    assert len(env["probes"]) == 1
    assert env["probes"][0]["name"] == "ok"
    assert env["probes"][0]["verdict"] == "pass"
    assert env["probes"][0]["duration_ms"] >= 0
    # ISO-ish UTC timestamp ending in Z
    assert env["checked_at"].endswith("Z")


@pytest.mark.asyncio
async def test_tuple_return_captures_detail():
    async def noisy():
        return ("pass", "module imported ok")

    env = await build_deep_health("sherlock", [noisy])
    assert env["probes"][0]["detail"] == "module imported ok"


@pytest.mark.asyncio
async def test_plain_string_detail_is_none():
    async def terse():
        return "pass"

    env = await build_deep_health("sherlock", [terse])
    assert env["probes"][0]["detail"] is None


# ─── Verdict aggregation ─────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_all_pass_gives_pass():
    async def a():
        return "pass"

    async def b():
        return "pass"

    env = await build_deep_health("svc", [a, b])
    assert env["verdict"] == "pass"
    assert env["required_failed"] == 0


@pytest.mark.asyncio
async def test_any_fail_gives_fail():
    async def a():
        return "pass"

    async def b():
        return ("fail", "something broke")

    env = await build_deep_health("svc", [a, b])
    assert env["verdict"] == "fail"
    assert env["required_failed"] == 1


@pytest.mark.asyncio
async def test_warn_without_fail_gives_warn():
    async def a():
        return "pass"

    async def b():
        return ("warn", "degraded")

    env = await build_deep_health("svc", [a, b])
    assert env["verdict"] == "warn"
    assert env["required_failed"] == 0


@pytest.mark.asyncio
async def test_unknown_verdict_becomes_fail():
    async def weird():
        return "maybe"

    env = await build_deep_health("svc", [weird])
    assert env["verdict"] == "fail"
    assert env["probes"][0]["verdict"] == "fail"


@pytest.mark.asyncio
async def test_malformed_return_becomes_fail():
    async def broken():
        return 42  # not a string, not a (str, str|None) tuple

    env = await build_deep_health("svc", [broken])
    assert env["verdict"] == "fail"
    assert "malformed" in (env["probes"][0]["detail"] or "")


# ─── Empty list ──────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_empty_probe_list_is_warn():
    env = await build_deep_health("svc", [])
    assert env["verdict"] == "warn"
    assert env["probes"] == []
    assert env["detail"] == "no probes registered"


# ─── Timeout + exception handling ────────────────────────────────────────────


@pytest.mark.asyncio
async def test_timeout_converted_to_fail():
    async def slow():
        await asyncio.sleep(1.0)
        return "pass"

    env = await build_deep_health("svc", [slow], timeout=0.05)
    probe = env["probes"][0]
    assert probe["verdict"] == "fail"
    assert "timeout" in (probe["detail"] or "").lower()
    assert env["verdict"] == "fail"


@pytest.mark.asyncio
async def test_exception_converted_to_fail():
    async def boom():
        raise ConnectionError("backend down")

    env = await build_deep_health("svc", [boom])
    probe = env["probes"][0]
    assert probe["verdict"] == "fail"
    assert "ConnectionError" in (probe["detail"] or "")
    assert "backend down" in (probe["detail"] or "")


@pytest.mark.asyncio
async def test_misbehaving_probe_does_not_take_down_peers():
    async def good():
        return "pass"

    async def bad():
        raise RuntimeError("nope")

    env = await build_deep_health("svc", [good, bad])
    names = {p["name"]: p for p in env["probes"]}
    assert names["good"]["verdict"] == "pass"
    assert names["bad"]["verdict"] == "fail"
    assert env["verdict"] == "fail"
    assert env["required_failed"] == 1


# ─── Parallel execution ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_probes_run_in_parallel():
    """Three 100ms probes should total ~100ms, not 300ms."""

    async def p1():
        await asyncio.sleep(0.1)
        return "pass"

    async def p2():
        await asyncio.sleep(0.1)
        return "pass"

    async def p3():
        await asyncio.sleep(0.1)
        return "pass"

    started = time.perf_counter()
    env = await build_deep_health("svc", [p1, p2, p3], timeout=2.0)
    elapsed_ms = (time.perf_counter() - started) * 1000

    # Expect parallelism: a sequential run would take >=300ms. Allow 200ms
    # slack for CI scheduler jitter — still well under 300ms.
    assert elapsed_ms < 250, f"probes did not run in parallel: took {elapsed_ms}ms"
    assert env["verdict"] == "pass"
    assert len(env["probes"]) == 3
