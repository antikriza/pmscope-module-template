"""Contract test — every wrapper in Task 4 must expose `/health/deep`.

This test does not boot each wrapper (their runtime deps are Docker-installed)
— instead it verifies the *shape* of each main.py: an import of
`build_deep_health` and a registered FastAPI route at `/health/deep`.

If this test fails after adding a new wrapper, update `EXPECTED_WRAPPERS` and
mirror the `/health/deep` pattern from any existing wrapper.
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[3]

EXPECTED_WRAPPERS: list[str] = [
    "sherlock-wrapper",
    "amass-wrapper",
    "maigret-wrapper",
    "email-tools",
    "phone-tools",
    "corporate-tools",
    "image-tools",
    "infra-tools",
    "instagram-tools",
    "telegram-tools",
    "twitter-tools",
    "reddit-tools",
    "linkedin-tools",
    "darkweb-monitor",
    "osintkit-wrapper",
    "rusprofile-wrapper",
    "media-tools",
    "court-tools",
    "traffic-tools",
    "finance-tools",
    "sanctions-tools",
    "trade-tools",
    "spiderfoot-wrapper",
    "gemini-connector",
]


@pytest.mark.parametrize("wrapper", EXPECTED_WRAPPERS)
def test_wrapper_imports_build_deep_health(wrapper: str) -> None:
    main_py = REPO_ROOT / "services" / wrapper / "src" / "main.py"
    assert main_py.exists(), f"{main_py} missing"
    src = main_py.read_text()
    assert "from pmscope.health import build_deep_health" in src, (
        f"{wrapper}: missing `from pmscope.health import build_deep_health`"
    )


@pytest.mark.parametrize("wrapper", EXPECTED_WRAPPERS)
def test_wrapper_registers_deep_health_route(wrapper: str) -> None:
    main_py = REPO_ROOT / "services" / wrapper / "src" / "main.py"
    src = main_py.read_text()
    assert '@app.get("/health/deep")' in src, (
        f"{wrapper}: missing `@app.get(\"/health/deep\")` route"
    )
    assert "build_deep_health(" in src, (
        f"{wrapper}: route defined but does not call `build_deep_health(...)`"
    )


@pytest.mark.parametrize("wrapper", EXPECTED_WRAPPERS)
def test_wrapper_probe_imports_primary_runner(wrapper: str) -> None:
    """Verify the probe actually touches a runner-style module (Task 4.6)."""
    main_py = REPO_ROOT / "services" / wrapper / "src" / "main.py"
    src = main_py.read_text()
    # Find the /health/deep block.
    marker = '@app.get("/health/deep")'
    assert marker in src
    after = src[src.index(marker):]
    # The probe body is the next ~30 lines. Look for `from src.` inside it.
    block = "\n".join(after.splitlines()[:30])
    assert "from src." in block, (
        f"{wrapper}: /health/deep block does not import a `src.*` module — "
        "probe is not exercising the primary runner"
    )
