"""Tests for the v1 ModuleManifest Pydantic schema."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from pmscope.manifest import ModuleManifest


def _base() -> dict:
    """Minimal valid manifest dict using build_context."""
    return {
        "name": "shodan",
        "display_name": "Shodan",
        "version": "1.0.0",
        "build_context": "./services/shodan-tools",
    }


# ---------------------------------------------------------------------------
# Valid manifests
# ---------------------------------------------------------------------------

def test_valid_manifest_with_digest_pinned_image():
    m = ModuleManifest(
        name="shodan",
        display_name="Shodan",
        version="1.0.0",
        docker_image="ghcr.io/pm-scope/shodan@sha256:abcd1234",
    )
    assert m.name == "shodan"
    assert m.docker_image is not None


def test_valid_manifest_with_build_context():
    m = ModuleManifest(**_base())
    assert m.build_context == "./services/shodan-tools"
    assert m.docker_image is None


def test_defaults_are_sensible():
    m = ModuleManifest(**_base())
    assert m.manifest_version == 1
    assert m.deprecated is False
    assert m.watchlist_severity == "medium"
    assert m.entity_types == []
    assert m.api_keys_required == []


# ---------------------------------------------------------------------------
# Invalid docker_image
# ---------------------------------------------------------------------------

def test_rejects_latest_tag():
    with pytest.raises(ValidationError, match="digest-pinned"):
        ModuleManifest(
            name="x", display_name="X", version="1.0.0",
            docker_image="myimg:latest",
        )


def test_rejects_tag_without_digest():
    with pytest.raises(ValidationError, match="digest-pinned"):
        ModuleManifest(
            name="x", display_name="X", version="1.0.0",
            docker_image="ghcr.io/pm-scope/shodan:v1.2.3",
        )


# ---------------------------------------------------------------------------
# docker_image / build_context mutual exclusion
# ---------------------------------------------------------------------------

def test_rejects_both_image_and_build_context():
    with pytest.raises(ValidationError, match="Cannot specify both"):
        ModuleManifest(
            name="x", display_name="X", version="1.0.0",
            docker_image="x@sha256:abc",
            build_context="./x",
        )


def test_rejects_neither_image_nor_build_context():
    with pytest.raises(ValidationError, match="Must specify either"):
        ModuleManifest(name="x", display_name="X", version="1.0.0")


# ---------------------------------------------------------------------------
# Name validation
# ---------------------------------------------------------------------------

def test_rejects_uppercase_name():
    with pytest.raises(ValidationError):
        ModuleManifest(name="Shodan", display_name="X", version="1.0.0",
                       build_context="./x")


def test_rejects_digit_start_name():
    with pytest.raises(ValidationError):
        ModuleManifest(name="1shodan", display_name="X", version="1.0.0",
                       build_context="./x")


def test_accepts_hyphenated_name():
    m = ModuleManifest(name="shodan-tools", display_name="X", version="1.0.0",
                       build_context="./x")
    assert m.name == "shodan-tools"


# ---------------------------------------------------------------------------
# Version validation
# ---------------------------------------------------------------------------

def test_rejects_non_semver_version():
    with pytest.raises(ValidationError):
        ModuleManifest(name="x", display_name="X", version="1.2",
                       build_context="./x")


def test_accepts_semver_with_prerelease():
    m = ModuleManifest(name="x", display_name="X", version="1.2.3-beta.1",
                       build_context="./x")
    assert m.version == "1.2.3-beta.1"


# ---------------------------------------------------------------------------
# chat_command validation
# ---------------------------------------------------------------------------

def test_rejects_chat_command_without_slash():
    with pytest.raises(ValidationError, match="must start with /"):
        ModuleManifest(name="x", display_name="X", version="1.0.0",
                       build_context="./x", chat_command="shodan")


def test_accepts_chat_command_with_slash():
    m = ModuleManifest(name="x", display_name="X", version="1.0.0",
                       build_context="./x", chat_command="/shodan")
    assert m.chat_command == "/shodan"


# ---------------------------------------------------------------------------
# extra="forbid"
# ---------------------------------------------------------------------------

def test_rejects_unknown_field():
    with pytest.raises(ValidationError):
        ModuleManifest(name="x", display_name="X", version="1.0.0",
                       build_context="./x", random_unknown_field="oops")


# ---------------------------------------------------------------------------
# JSON Schema export
# ---------------------------------------------------------------------------

def test_json_schema_export_is_valid_json():
    path = Path(__file__).parent.parent / "manifest_schema.json"
    assert path.exists(), "manifest_schema.json must be committed alongside manifest.py"
    data = json.loads(path.read_text())
    assert "properties" in data or "$defs" in data, (
        "Schema must contain 'properties' or '$defs' key"
    )


def test_json_schema_has_required_fields():
    path = Path(__file__).parent.parent / "manifest_schema.json"
    data = json.loads(path.read_text())
    props = data.get("properties", {})
    assert "name" in props
    assert "version" in props
    assert "docker_image" in props or "docker_image" in str(data)
