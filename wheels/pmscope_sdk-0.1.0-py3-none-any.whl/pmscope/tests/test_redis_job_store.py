"""Tests for pmscope.redis_job_store — InMemoryJobStore and factory."""
import logging
import sys
import os

import pytest

# Ensure lib/ is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from pmscope.redis_job_store import create_job_store, InMemoryJobStore, RedisJobStore


def test_create_job_store_empty_url_returns_in_memory():
    """Empty redis_url should return InMemoryJobStore."""
    store = create_job_store(redis_url="", prefix="test")
    assert isinstance(store, InMemoryJobStore)


def test_create_job_store_unreachable_returns_in_memory():
    """Unreachable Redis should return InMemoryJobStore."""
    store = create_job_store(redis_url="redis://localhost:59999/0", prefix="test")
    assert isinstance(store, InMemoryJobStore)


def test_create_job_store_logs_warning_on_failure(caplog):
    """Unreachable Redis should log a CRITICAL with DATA LOSS RISK marker."""
    with caplog.at_level(logging.CRITICAL, logger="pmscope.redis_job_store"):
        store = create_job_store(redis_url="redis://localhost:59999/0", prefix="test")
    assert isinstance(store, InMemoryJobStore)
    assert any(
        r.levelname == "CRITICAL" and "DATA LOSS RISK" in r.getMessage()
        for r in caplog.records
    )


def test_create_job_store_logs_warning_no_url(caplog):
    """Empty REDIS_URL should log a CRITICAL with no REDIS_URL configured marker."""
    with caplog.at_level(logging.CRITICAL, logger="pmscope.redis_job_store"):
        store = create_job_store(redis_url="", prefix="test")
    assert isinstance(store, InMemoryJobStore)
    assert any(
        r.levelname == "CRITICAL" and "no REDIS_URL configured" in r.getMessage()
        for r in caplog.records
    )


def test_in_memory_store_roundtrip_unknown_dict_field():
    """InMemoryJobStore preserves dict fields through roundtrip."""
    store = InMemoryJobStore()
    store.create_job("j1", "target", "company", custom_data={"key": "value"})
    job = store.get_job("j1")
    assert job["custom_data"] == {"key": "value"}
    assert isinstance(job["custom_data"], dict)


def test_deserialize_unknown_json_field():
    """_deserialize should auto-detect JSON strings for unknown fields."""
    raw = {
        "job_id": "j1",
        "status": "completed",
        "target": "Acme",
        "target_type": "company",
        "created_at": "1710000000.0",
        "started_at": "",
        "completed_at": "1710000060.0",
        "error": "",
        "custom_data": '{"key": "value"}',
        "custom_list": '[1, 2, 3]',
        "plain_string": "hello",
    }
    result = RedisJobStore._deserialize(raw)
    assert result["custom_data"] == {"key": "value"}
    assert result["custom_list"] == [1, 2, 3]
    assert result["plain_string"] == "hello"
    assert result["created_at"] == 1710000000.0
    assert result["error"] is None


def test_deserialize_string_fields_never_json_parsed():
    """Core job fields (target, error, etc.) must stay as strings even if valid JSON."""
    raw = {
        "job_id": "j1",
        "status": "completed",
        "target": '["acme"]',          # valid JSON, but must stay str
        "target_type": '{"type": "co"}',  # valid JSON, but must stay str
        "error": '{"code": 500}',       # valid JSON, but must stay str
        "created_at": "1710000000.0",
        "started_at": "",
        "completed_at": "",
    }
    result = RedisJobStore._deserialize(raw)
    assert result["target"] == '["acme"]'
    assert isinstance(result["target"], str)
    assert result["target_type"] == '{"type": "co"}'
    assert isinstance(result["target_type"], str)
    assert result["error"] == '{"code": 500}'
    assert isinstance(result["error"], str)


def test_deserialize_domain_field_never_json_parsed():
    """domain field must stay as string even if it looks like JSON (e.g. IPv6-style brackets)."""
    raw = {
        "job_id": "j1",
        "status": "completed",
        "target": "example.com",
        "target_type": "domain",
        "created_at": "1710000000.0",
        "started_at": "",
        "completed_at": "1710000060.0",
        "error": "",
        "domain": '["acme"]',  # urlparse can produce bracketed netloc
    }
    result = RedisJobStore._deserialize(raw)
    assert result["domain"] == '["acme"]'
    assert isinstance(result["domain"], str)


def test_deserialize_malformed_json_stays_as_string():
    """Values starting with { or [ that aren't valid JSON stay as raw strings."""
    raw = {
        "job_id": "j1",
        "status": "completed",
        "target": "Acme",
        "target_type": "company",
        "created_at": "1710000000.0",
        "started_at": "",
        "completed_at": "",
        "error": "",
        "broken_json": "{not valid json",
        "broken_list": "[incomplete",
    }
    result = RedisJobStore._deserialize(raw)
    assert result["broken_json"] == "{not valid json"
    assert result["broken_list"] == "[incomplete"


def test_deserialize_unparseable_float_returns_none():
    """Non-numeric float fields should deserialize to None."""
    raw = {
        "job_id": "j1",
        "status": "completed",
        "target": "Acme",
        "target_type": "company",
        "created_at": "not-a-number",
        "started_at": "also-bad",
        "completed_at": "",
        "error": "",
    }
    result = RedisJobStore._deserialize(raw)
    assert result["created_at"] is None
    assert result["started_at"] is None


class TestInMemoryJobStore:
    def test_create_and_get(self):
        store = InMemoryJobStore()
        store.create_job("j1", "Acme", "company")
        job = store.get_job("j1")
        assert job["status"] == "queued"
        assert job["target"] == "Acme"
        assert job["target_type"] == "company"
        assert job["created_at"] is not None

    def test_update(self):
        store = InMemoryJobStore()
        store.create_job("j1", "Acme", "company")
        store.update_job("j1", status="running", started_at=1234.0)
        job = store.get_job("j1")
        assert job["status"] == "running"
        assert job["started_at"] == 1234.0

    def test_get_missing_returns_none(self):
        store = InMemoryJobStore()
        assert store.get_job("missing") is None

    def test_update_missing_is_noop(self):
        store = InMemoryJobStore()
        store.update_job("missing", status="running")  # no error
        assert store.get_job("missing") is None

    def test_get_returns_deep_copy(self):
        store = InMemoryJobStore()
        store.create_job("j1", "Acme", "company", snapshots=[{"a": 1}])
        job = store.get_job("j1")
        job["snapshots"][0]["a"] = 999
        assert store.get_job("j1")["snapshots"][0]["a"] == 1

    def test_list_jobs_sorted_by_created_at(self):
        store = InMemoryJobStore()
        store.create_job("j1", "A", "company")
        store.create_job("j2", "B", "company")
        store.create_job("j3", "C", "company")
        jobs = store.list_jobs(limit=2)
        assert len(jobs) == 2
        assert jobs[0]["job_id"] == "j3"  # newest first

    def test_extra_kwargs_stored(self):
        store = InMemoryJobStore()
        store.create_job("j1", "Acme", "company", domain="acme.com")
        job = store.get_job("j1")
        assert job["domain"] == "acme.com"

    def test_list_jobs_with_none_created_at(self):
        """list_jobs must not crash when a job has created_at=None."""
        store = InMemoryJobStore()
        store.create_job("j1", "A", "company")
        store.create_job("j2", "B", "company")
        # Set created_at=None after both jobs exist (avoids eviction during create_job)
        store.update_job("j1", created_at=None)
        jobs = store.list_jobs()
        assert len(jobs) == 2
        # j1 has created_at=None (sorts as 0), j2 has a real timestamp
        assert jobs[0]["job_id"] == "j2"


# ─────────────────────────────────────────────────────────────
# P0 resilience: CRITICAL log + Prometheus gauge on fallback
# ─────────────────────────────────────────────────────────────


def test_fallback_logs_critical_on_unreachable_redis(caplog):
    """Unreachable Redis must emit a CRITICAL log with DATA LOSS RISK marker."""
    with caplog.at_level(logging.CRITICAL, logger="pmscope.redis_job_store"):
        store = create_job_store(redis_url="redis://localhost:59999/0", prefix="t1")
    assert isinstance(store, InMemoryJobStore)
    assert any(
        r.levelname == "CRITICAL" and "DATA LOSS RISK" in r.getMessage()
        for r in caplog.records
    )


def test_fallback_logs_critical_on_empty_url(caplog):
    """Empty redis_url must emit a CRITICAL log with no REDIS_URL configured marker."""
    with caplog.at_level(logging.CRITICAL, logger="pmscope.redis_job_store"):
        store = create_job_store(redis_url="", prefix="t2")
    assert isinstance(store, InMemoryJobStore)
    assert any(
        r.levelname == "CRITICAL" and "no REDIS_URL configured" in r.getMessage()
        for r in caplog.records
    )


def test_prometheus_gauge_flips_on_fallback():
    """pmscope_redis_fallback_active gauge reads 1 after fallback, 0 after healthy Redis."""
    pytest.importorskip("prometheus_client")
    from pmscope.redis_job_store import _REDIS_FALLBACK_GAUGE
    assert _REDIS_FALLBACK_GAUGE is not None, "gauge must be non-None when prometheus_client is available"

    # Trigger fallback (unreachable Redis) — gauge for prefix "t3" must flip to 1
    create_job_store(redis_url="redis://localhost:59999/0", prefix="t3")
    val = _REDIS_FALLBACK_GAUGE.labels(prefix="t3")._value.get()
    assert val == 1.0, f"expected gauge=1 after fallback, got {val}"
