"""
Unit tests for pmscope.circuit_breaker.

Covers:
- Passthrough when purgatory not available (ImportError path)
- closed state after successful call
- Open state after threshold failures
- Half-open probe after cooldown: success closes, failure re-opens
- Initial unknown->closed transition does NOT emit CRITICAL log
- Real state change (closed->open) emits CRITICAL log
- Prometheus gauge set to 1 on open, 0 on close
- get_all_states() returns a copy (mutating does not affect internal cache)
"""
import asyncio
import os
import sys

import pytest
from unittest.mock import MagicMock, call

# Ensure lib/ is on sys.path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

# Set fast thresholds BEFORE importing the module so module-level constants pick them up.
os.environ["PMSCOPE_CIRCUIT_FAIL_THRESHOLD"] = "3"
os.environ["PMSCOPE_CIRCUIT_COOLDOWN_SECONDS"] = "1"

# Re-import fresh to pick up env-var values set above
import importlib
import pmscope.circuit_breaker as cb

importlib.reload(cb)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_state():
    """Clear state_cache and factory breaker registry between tests."""
    cb._state_cache.clear()
    if cb._factory is not None:
        # Internal breaker registry: factory.uow.contexts.breakers is a plain dict
        try:
            cb._factory.uow.contexts.breakers.clear()
        except AttributeError:
            pass
    yield
    cb._state_cache.clear()
    if cb._factory is not None:
        try:
            cb._factory.uow.contexts.breakers.clear()
        except AttributeError:
            pass


# ---------------------------------------------------------------------------
# 1. Passthrough when purgatory missing
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_passthrough_when_purgatory_missing(monkeypatch):
    """When purgatory not available, call_with_breaker still awaits coro and returns result."""
    monkeypatch.setattr(cb, "_PURGATORY_AVAILABLE", False)
    monkeypatch.setattr(cb, "_factory", None)

    async def good():
        return "ok"

    result = await cb.call_with_breaker("svc-a", good())
    assert result == "ok"
    # Passthrough mode: no state recorded
    assert cb.get_all_states() == {}


# ---------------------------------------------------------------------------
# 2. Successful call -> closed state
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_closes_on_success():
    """A single successful call records state='closed'."""
    if not cb._PURGATORY_AVAILABLE:
        pytest.skip("purgatory not installed in this environment")

    async def good():
        return 42

    result = await cb.call_with_breaker("svc-b", good())
    assert result == 42
    assert cb.get_all_states().get("svc-b") == "closed"


# ---------------------------------------------------------------------------
# 3. Threshold failures -> circuit opens
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_opens_after_threshold_failures():
    """After FAIL_THRESHOLD failures the next call raises the circuit-open exception."""
    if not cb._PURGATORY_AVAILABLE:
        pytest.skip("purgatory not installed")

    async def bad():
        raise RuntimeError("boom")

    # Trigger exactly FAIL_THRESHOLD (3) failures
    for _ in range(3):
        with pytest.raises(RuntimeError):
            await cb.call_with_breaker("svc-c", bad())

    # Next call should raise OpenedCircuit (OpenedState in purgatory 3.0.1)
    with pytest.raises(Exception) as exc_info:
        await cb.call_with_breaker("svc-c", bad())

    assert cb.OpenedCircuit is not None, "OpenedCircuit must be importable when purgatory present"
    assert isinstance(exc_info.value, cb.OpenedCircuit), (
        f"Expected OpenedCircuit, got {type(exc_info.value).__name__}"
    )
    assert cb.get_all_states().get("svc-c") == "open"


# ---------------------------------------------------------------------------
# 4. Half-open after cooldown: success closes
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_half_open_success_closes_circuit():
    """After cooldown the probe call succeeds -> state returns to 'closed'."""
    if not cb._PURGATORY_AVAILABLE:
        pytest.skip("purgatory not installed")

    async def bad():
        raise RuntimeError("boom")

    async def good():
        return "ok"

    # Open the circuit (3 failures)
    for _ in range(3):
        with pytest.raises(RuntimeError):
            await cb.call_with_breaker("svc-d", bad())

    assert cb.get_all_states().get("svc-d") == "open"

    # Wait past cooldown (1s configured in env var at top of file)
    await asyncio.sleep(1.2)

    # Probe with a successful call — should be allowed and close the circuit
    result = await cb.call_with_breaker("svc-d", good())
    assert result == "ok"
    assert cb.get_all_states().get("svc-d") == "closed"


# ---------------------------------------------------------------------------
# 5. Half-open after cooldown: failure re-opens
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_half_open_failure_reopens_circuit():
    """After cooldown a failed probe re-opens the circuit."""
    if not cb._PURGATORY_AVAILABLE:
        pytest.skip("purgatory not installed")

    async def bad():
        raise RuntimeError("boom")

    # Open the circuit (3 failures)
    for _ in range(3):
        with pytest.raises(RuntimeError):
            await cb.call_with_breaker("svc-e", bad())

    assert cb.get_all_states().get("svc-e") == "open"

    # Wait past cooldown
    await asyncio.sleep(1.2)

    # Probe with a failing call — should re-open the circuit
    with pytest.raises(RuntimeError):
        await cb.call_with_breaker("svc-e", bad())

    # Circuit should be open again (purgatory resets after failed probe)
    # The state may briefly re-close before re-opening — check it ended open
    with pytest.raises(Exception) as exc_info:
        await cb.call_with_breaker("svc-e", bad())

    assert cb.OpenedCircuit is not None
    assert isinstance(exc_info.value, cb.OpenedCircuit)
    assert cb.get_all_states().get("svc-e") == "open"


# ---------------------------------------------------------------------------
# 6. Initial unknown->closed does NOT emit CRITICAL log
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_initial_unknown_to_closed_does_not_log_critical(caplog):
    """First successful call (unknown->closed) must NOT produce a CRITICAL log record."""
    if not cb._PURGATORY_AVAILABLE:
        pytest.skip("purgatory not installed")

    with caplog.at_level("CRITICAL", logger="pmscope.circuit_breaker"):
        async def good():
            return 1

        await cb.call_with_breaker("svc-f", good())

    critical_logs = [r for r in caplog.records if r.levelname == "CRITICAL"]
    assert critical_logs == [], (
        f"Unexpected CRITICAL log on initial unknown->closed transition: {critical_logs}"
    )


# ---------------------------------------------------------------------------
# 7. Real state change (closed->open) emits CRITICAL log
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_real_state_change_logs_critical(caplog):
    """closed->open state transition must emit exactly one CRITICAL log containing service name."""
    if not cb._PURGATORY_AVAILABLE:
        pytest.skip("purgatory not installed")

    async def bad():
        raise RuntimeError("boom")

    with caplog.at_level("CRITICAL", logger="pmscope.circuit_breaker"):
        # Trigger 3 failures to open the circuit; first call records unknown->closed (no log),
        # subsequent calls stay closed until threshold, then transition to open (should log).
        for _ in range(3):
            with pytest.raises(RuntimeError):
                await cb.call_with_breaker("svc-g", bad())

    msgs = [r.getMessage() for r in caplog.records if r.levelname == "CRITICAL"]
    assert any("svc-g" in m and "open" in m for m in msgs), (
        f"Expected CRITICAL log with 'svc-g' and 'open', got: {msgs}"
    )


# ---------------------------------------------------------------------------
# 8. Prometheus gauge set to 1 on open
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_prometheus_gauge_set_on_open(monkeypatch):
    """Opening the circuit calls gauge.labels(service=...).set(1)."""
    if not cb._PURGATORY_AVAILABLE:
        pytest.skip("purgatory not installed")

    fake_gauge = MagicMock()
    monkeypatch.setattr(cb, "_CB_OPEN_GAUGE", fake_gauge)

    async def bad():
        raise RuntimeError("boom")

    for _ in range(3):
        with pytest.raises(RuntimeError):
            await cb.call_with_breaker("svc-h", bad())

    # Check that gauge.labels(service="svc-h").set(1) was called at least once
    label_calls = fake_gauge.labels.call_args_list
    has_open = any(
        kw.get("service") == "svc-h" or (args and args[0] == "svc-h")
        for args, kw in label_calls
    )
    assert has_open, f"expected labels(service='svc-h') call, got: {label_calls}"

    set_calls = fake_gauge.labels.return_value.set.call_args_list
    assert any(args[0] == 1 for args, _ in set_calls), (
        f"expected gauge.set(1) on open transition, got: {set_calls}"
    )


# ---------------------------------------------------------------------------
# 9. get_all_states returns a snapshot (copy), not live reference
# ---------------------------------------------------------------------------


def test_get_all_states_returns_snapshot():
    """Mutating the returned dict does not affect _state_cache."""
    cb._state_cache["svc-i"] = "open"
    snap = cb.get_all_states()
    assert snap == {"svc-i": "open"}
    # Mutate the snapshot
    snap["svc-i"] = "mutated"
    snap["svc-new"] = "closed"
    # Internal cache unchanged
    assert cb._state_cache.get("svc-i") == "open", (
        "get_all_states must return a copy, not the live dict"
    )
    assert "svc-new" not in cb._state_cache
