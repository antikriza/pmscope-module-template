"""Tests for pmscope.audit_buffer — size/time flush, drop-on-full, drain-on-stop.

Covers Phase 5 P3 requirements:
- REQ-08a: size flush at batch_size
- REQ-08b: time flush at flush_interval
- REQ-08c: drop-on-full backpressure with structlog WARN

Mocking strategy:
- httpx.MockTransport captures requests without real HTTP — lets us inspect
  the body and headers the buffer would send to /api/v1/audit/ingest.
- structlog warnings are captured via a stdlib logging bridge configured in
  the test fixture (structlog → stdlib → caplog). This keeps tests
  framework-neutral and avoids a separate structlog test fixture.
- The time-based flush test uses the simple `flush_interval=0.1 + asyncio.sleep(0.3)`
  approach (per PLAN 05-03 Task 1 instructions) — total runtime stays well
  under 1 second and avoids deterministic-clock plumbing complexity.
"""
from __future__ import annotations

import asyncio
import logging
import sys
import os
from typing import List

import pytest
import httpx
import structlog

# Ensure lib/ is importable when running pytest from repo root.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from pmscope.audit_buffer import AuditBuffer, AuditEvent  # noqa: E402


# ─────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────


def _make_event(i: int = 0) -> AuditEvent:
    return AuditEvent(
        action="module.query.start",
        timestamp="2026-01-01T00:00:00Z",
        payload_hash=f"{i:016x}"[:16],
        metadata={"entity_type": "username", "seq": i},
    )


def _make_mock_client(captured_requests: List[httpx.Request], status: int = 202) -> httpx.AsyncClient:
    """Build an httpx.AsyncClient backed by MockTransport that records every request."""

    async def handler(request: httpx.Request) -> httpx.Response:
        # Read the body so it is materialised before the client object is GC'd.
        _ = await request.aread() if hasattr(request, "aread") else request.read()
        captured_requests.append(request)
        return httpx.Response(status, json={"accepted": 0})

    transport = httpx.MockTransport(handler)
    return httpx.AsyncClient(transport=transport, timeout=5.0)


@pytest.fixture(autouse=True)
def _structlog_to_stdlib(caplog):
    """Bridge structlog warnings to the stdlib logger so caplog can see them.

    AuditBuffer uses `structlog.get_logger("pmscope.audit_buffer")`. By default
    structlog emits its own events without going through the stdlib logging
    machinery, which makes them invisible to pytest's `caplog` fixture. This
    autouse fixture configures structlog with a `LoggerFactory` that wraps
    stdlib logging — the standard documented pattern for capturing structlog
    output in tests.
    """
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.KeyValueRenderer(key_order=["event"]),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(logging.DEBUG),
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=False,
    )
    caplog.set_level(logging.DEBUG, logger="pmscope.audit_buffer")
    yield
    # Reset structlog config so other test files (test_redis_job_store etc.)
    # don't inherit our stdlib bridge.
    structlog.reset_defaults()


# ─────────────────────────────────────────────────────────────────────────
# REQ-08a — size flush
# ─────────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_flush_on_size():
    """Enqueue 100 events; mock client receives ONE POST with 100 events (REQ-08a)."""
    captured: List[httpx.Request] = []
    client = _make_mock_client(captured)
    buffer = AuditBuffer(
        ingest_url="http://test/api/v1/audit/ingest",
        token="test-token",
        client=client,
        batch_size=100,
        flush_interval=999.0,  # disable time trigger for this test
        max_queue=1000,
    )
    buffer.start()
    try:
        for i in range(100):
            buffer.append(_make_event(i))
        # Yield control so the background task can drain the queue.
        for _ in range(50):
            await asyncio.sleep(0.01)
            if captured:
                break
        assert len(captured) == 1, f"expected 1 POST, got {len(captured)}"
        body = httpx.Request(captured[0].method, captured[0].url, content=captured[0].content).read()
        import json
        payload = json.loads(body)
        assert "events" in payload
        assert len(payload["events"]) == 100
    finally:
        await buffer.stop()


# ─────────────────────────────────────────────────────────────────────────
# REQ-08b — time flush
# ─────────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_flush_on_time():
    """Enqueue 5 events; after flush_interval elapses, mock client receives 1 POST with 5 events (REQ-08b).

    Uses the simple short-interval approach (flush_interval=0.1, sleep 0.3)
    per PLAN 05-03 Task 1 — keeps total test runtime < 1 second.
    """
    captured: List[httpx.Request] = []
    client = _make_mock_client(captured)
    buffer = AuditBuffer(
        ingest_url="http://test/api/v1/audit/ingest",
        token="test-token",
        client=client,
        batch_size=100,         # too high to size-trigger
        flush_interval=0.1,     # 100ms time trigger
        max_queue=1000,
    )
    buffer.start()
    try:
        for i in range(5):
            buffer.append(_make_event(i))
        # Wait long enough for time-flush to fire (3× the interval).
        await asyncio.sleep(0.4)
        assert len(captured) >= 1, f"expected at least 1 POST after time-flush, got {len(captured)}"
        # First flush should contain all 5 events (no further events appended after).
        import json
        body = captured[0].content
        payload = json.loads(body)
        assert len(payload["events"]) == 5
    finally:
        await buffer.stop()


# ─────────────────────────────────────────────────────────────────────────
# REQ-08c — drop-on-full
# ─────────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_drops_on_full(caplog):
    """max_queue=10; enqueue 11 without draining; assert exactly 1 dropped event + WARN log (REQ-08c)."""
    captured: List[httpx.Request] = []
    client = _make_mock_client(captured)
    buffer = AuditBuffer(
        ingest_url="http://test/api/v1/audit/ingest",
        token="test-token",
        client=client,
        batch_size=999,
        flush_interval=999.0,
        max_queue=10,
    )
    # Do NOT start the background task — that way nothing drains the queue
    # and the 11th append is forced to drop.
    with caplog.at_level(logging.WARNING, logger="pmscope.audit_buffer"):
        for i in range(11):
            buffer.append(_make_event(i))

    # Assert exactly one drop happened (queue holds 10, 11th is rejected).
    drop_records = [r for r in caplog.records if "audit_buffer.dropped" in r.getMessage()]
    assert len(drop_records) == 1, (
        f"expected exactly 1 'audit_buffer.dropped' WARN, got {len(drop_records)}: "
        f"{[r.getMessage() for r in drop_records]}"
    )
    assert "queue_full" in drop_records[0].getMessage()
    # Cleanup the underlying httpx client (buffer.stop() not needed since we never started).
    await client.aclose()


# ─────────────────────────────────────────────────────────────────────────
# Drain-on-stop
# ─────────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_drains_on_stop():
    """Enqueue 3 events; stop() flushes them as a final batch."""
    captured: List[httpx.Request] = []
    client = _make_mock_client(captured)
    buffer = AuditBuffer(
        ingest_url="http://test/api/v1/audit/ingest",
        token="test-token",
        client=client,
        batch_size=100,
        flush_interval=999.0,   # no time-trigger during the brief test
        max_queue=1000,
    )
    buffer.start()
    for i in range(3):
        buffer.append(_make_event(i))
    # Tiny pause so the background task definitely sees them on the queue.
    await asyncio.sleep(0.05)
    await buffer.stop()
    assert len(captured) >= 1, "stop() must drain a final batch"
    import json
    # All 3 events should be in the final flush (or split across multiple flushes — accept either).
    total = 0
    for r in captured:
        payload = json.loads(r.content)
        total += len(payload["events"])
    assert total == 3, f"expected 3 events drained total across {len(captured)} POSTs, got {total}"


# ─────────────────────────────────────────────────────────────────────────
# append() is non-async / non-blocking
# ─────────────────────────────────────────────────────────────────────────


def test_append_is_nonblocking():
    """append() must be a regular sync function — callable from non-async code."""
    # Build the buffer inside a tiny event loop, but call .append() outside any await.
    loop = asyncio.new_event_loop()
    try:
        async def _setup():
            captured: List[httpx.Request] = []
            client = _make_mock_client(captured)
            return AuditBuffer(
                ingest_url="http://test/api/v1/audit/ingest",
                token="test-token",
                client=client,
                batch_size=100,
                flush_interval=999.0,
                max_queue=1000,
            ), client

        buffer, client = loop.run_until_complete(_setup())

        # Now call append() as a regular synchronous function.
        # If append() were `async def`, this would emit a "coroutine was never awaited" RuntimeWarning
        # and the call would have no effect — neither raise nor enqueue.
        result = buffer.append(_make_event(0))
        assert result is None, "append() must return None (sync, non-coroutine)"

        # Sanity: append() should not be a coroutine function.
        import inspect
        assert not inspect.iscoroutinefunction(buffer.append), "append() must NOT be async"

        loop.run_until_complete(client.aclose())
    finally:
        loop.close()


# ─────────────────────────────────────────────────────────────────────────
# Wire format — X-Internal-Token header present on every POST
# ─────────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_post_includes_internal_token():
    """Every POST emitted by the buffer must include X-Internal-Token: <token>."""
    captured: List[httpx.Request] = []
    client = _make_mock_client(captured)
    buffer = AuditBuffer(
        ingest_url="http://test/api/v1/audit/ingest",
        token="test-token",
        client=client,
        batch_size=2,           # tiny batch to trigger flush quickly
        flush_interval=999.0,
        max_queue=1000,
    )
    buffer.start()
    try:
        buffer.append(_make_event(0))
        buffer.append(_make_event(1))
        for _ in range(50):
            await asyncio.sleep(0.01)
            if captured:
                break
        assert len(captured) == 1
        assert captured[0].headers.get("X-Internal-Token") == "test-token"
    finally:
        await buffer.stop()


# ─────────────────────────────────────────────────────────────────────────
# HTTP failure handling — log WARN, do not requeue
# ─────────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_http_failure_logs_warn(caplog):
    """HTTP 500 from ingest endpoint → WARN log audit_buffer.flush_rejected, events NOT requeued."""
    captured: List[httpx.Request] = []
    client = _make_mock_client(captured, status=500)
    buffer = AuditBuffer(
        ingest_url="http://test/api/v1/audit/ingest",
        token="test-token",
        client=client,
        batch_size=2,
        flush_interval=999.0,
        max_queue=1000,
    )
    buffer.start()
    try:
        with caplog.at_level(logging.WARNING, logger="pmscope.audit_buffer"):
            buffer.append(_make_event(0))
            buffer.append(_make_event(1))
            for _ in range(50):
                await asyncio.sleep(0.01)
                if captured:
                    break

        # Exactly one POST attempt was made (events not requeued for retry).
        assert len(captured) == 1, f"events must NOT be requeued on 5xx, got {len(captured)} POSTs"

        rejected = [r for r in caplog.records if "audit_buffer.flush_rejected" in r.getMessage()]
        assert len(rejected) >= 1, "expected audit_buffer.flush_rejected WARN log"
        msg = rejected[0].getMessage()
        assert "500" in msg, f"WARN log must include status code, got: {msg}"
    finally:
        await buffer.stop()


@pytest.mark.asyncio
async def test_http_exception_logs_warn(caplog):
    """httpx.RequestError raised mid-flush → WARN log audit_buffer.flush_failed, no crash."""
    captured: List[httpx.Request] = []

    async def _raising_handler(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        raise httpx.ConnectError("simulated network failure")

    transport = httpx.MockTransport(_raising_handler)
    client = httpx.AsyncClient(transport=transport, timeout=5.0)

    buffer = AuditBuffer(
        ingest_url="http://test/api/v1/audit/ingest",
        token="test-token",
        client=client,
        batch_size=2,
        flush_interval=999.0,
        max_queue=1000,
    )
    buffer.start()
    try:
        with caplog.at_level(logging.WARNING, logger="pmscope.audit_buffer"):
            buffer.append(_make_event(0))
            buffer.append(_make_event(1))
            for _ in range(50):
                await asyncio.sleep(0.01)
                if captured:
                    break

        failed = [r for r in caplog.records if "audit_buffer.flush_failed" in r.getMessage()]
        assert len(failed) >= 1, "expected audit_buffer.flush_failed WARN log on httpx exception"
    finally:
        await buffer.stop()
