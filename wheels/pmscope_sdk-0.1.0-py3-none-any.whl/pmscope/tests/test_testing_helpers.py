"""Tests for the pmscope.testing contract assertion helpers (Plan 05-02).

These exercise three drop-in helpers that external module repos use in their
CI to gate against contract drift:

  - assert_watchlist_response_shape(json) — canonical /watchlist/scan shape
  - assert_health_response_shape(json)    — canonical /health shape
  - assert_module_manifest_valid(dict)    — pydantic v2 ModuleManifest validation

Per RESEARCH.md Pattern 4 (lines ~686-743), the helpers are pure imports —
NOT a pytest plugin — so no entry_points or conftest tricks are needed.
"""
from __future__ import annotations

import pydantic
import pytest

from pmscope.testing import (
    assert_health_response_shape,
    assert_module_manifest_valid,
    assert_watchlist_response_shape,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_VALID_WATCHLIST_RESPONSE = {
    "entities": [{"type": "username", "value": "x"}],
    "attributes": {"confidence": 0.5},
    "mentions": [],
    "metadata": {
        "scan_id": "1",
        "timestamp": "2026-01-01T00:00:00Z",
        "source_tool": "x",
    },
}

_VALID_MANIFEST_DICT = {
    "manifest_version": 1,
    "name": "test-module",
    "display_name": "Test Module",
    "version": "0.1.0",
    "build_context": "./",
    "sdk_version": ">=0.1,<0.2",
    "entity_types": ["username"],
    "watchlist_severity": "low",
}


# ---------------------------------------------------------------------------
# assert_watchlist_response_shape
# ---------------------------------------------------------------------------

def test_assert_watchlist_shape_accepts_valid():
    # No exception means happy path.
    result = assert_watchlist_response_shape(_VALID_WATCHLIST_RESPONSE)
    assert result is None


def test_assert_watchlist_shape_rejects_missing_entities():
    bad = {k: v for k, v in _VALID_WATCHLIST_RESPONSE.items() if k != "entities"}
    with pytest.raises(AssertionError, match="entities"):
        assert_watchlist_response_shape(bad)


def test_assert_watchlist_shape_rejects_non_dict():
    with pytest.raises(AssertionError, match="expected dict"):
        assert_watchlist_response_shape(["not", "a", "dict"])


def test_assert_watchlist_shape_rejects_wrong_attribute_type():
    bad = dict(_VALID_WATCHLIST_RESPONSE)
    bad["attributes"] = ["should", "be", "a", "dict"]
    with pytest.raises(AssertionError, match="attributes"):
        assert_watchlist_response_shape(bad)


# ---------------------------------------------------------------------------
# assert_health_response_shape
# ---------------------------------------------------------------------------

def test_assert_health_shape_accepts_healthy():
    assert_health_response_shape({"status": "healthy", "service": "x"})


def test_assert_health_shape_accepts_degraded():
    assert_health_response_shape({"status": "degraded", "service": "x"})


def test_assert_health_shape_rejects_invalid_status():
    with pytest.raises(AssertionError, match="invalid status"):
        assert_health_response_shape({"status": "green", "service": "x"})


def test_assert_health_shape_rejects_missing_service():
    with pytest.raises(AssertionError, match="service"):
        assert_health_response_shape({"status": "healthy"})


# ---------------------------------------------------------------------------
# assert_module_manifest_valid
# ---------------------------------------------------------------------------

def test_assert_module_manifest_valid_returns_model():
    result = assert_module_manifest_valid(_VALID_MANIFEST_DICT)
    assert result.name == "test-module"
    assert result.manifest_version == 1


def test_assert_module_manifest_valid_rejects_unpinned_image():
    bad = {
        "manifest_version": 1,
        "name": "test-module",
        "display_name": "Test Module",
        "version": "0.1.0",
        "docker_image": "ghcr.io/x:latest",
    }
    with pytest.raises(pydantic.ValidationError, match="@sha256:"):
        assert_module_manifest_valid(bad)


def test_assert_module_manifest_valid_rejects_missing_name():
    bad = {
        "manifest_version": 1,
        "display_name": "x",
        "version": "0.1.0",
        "build_context": "./",
    }
    with pytest.raises(pydantic.ValidationError, match="name"):
        assert_module_manifest_valid(bad)
