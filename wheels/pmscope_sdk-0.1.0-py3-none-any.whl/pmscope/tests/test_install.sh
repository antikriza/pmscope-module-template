#!/usr/bin/env bash
# Smoke test: build wheel, install in temp venv, verify imports.
# Used by Wave 0 verification + .github/workflows/sdk-tag.yml.
set -euo pipefail

# Resolve script dir → lib/pmscope/tests; lib root is two parents up.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

TMPDIR="$(mktemp -d)"
trap "rm -rf $TMPDIR" EXIT

cd "$LIB_DIR"
pip install --quiet hatchling build
python -m build --wheel --outdir "$TMPDIR/dist" >/dev/null

python -m venv "$TMPDIR/venv"
# shellcheck disable=SC1091
source "$TMPDIR/venv/bin/activate"
pip install --quiet "$TMPDIR/dist/"pmscope_sdk-*.whl

python -c "
from pmscope import build_wrapper_app
from pmscope.manifest import ModuleManifest, ApiKeyRequirement
from pmscope.service_auth import add_internal_auth_middleware
print('SDK install smoke test: PASS')
"

echo 'OK'
