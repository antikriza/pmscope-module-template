"""Unit tests for pmscope.base_wrapper.build_wrapper_app factory.

Uses FastAPI TestClient — no Docker, no Redis, no database required.
"""
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient


async def _sample_handler(entity_type: str, entity_value: str) -> dict:
    return {
        "entities": [{"type": entity_type, "value": entity_value}],
        "attributes": {"handler_called": True},
        "mentions": [],
        "metadata": {"scan_source": "test-svc"},
    }


async def _raising_handler(entity_type: str, entity_value: str) -> dict:
    raise RuntimeError("simulated handler failure")


async def _extras_callback() -> dict:
    return {"extra_field": "extra_value", "feature_enabled": True}


@pytest.fixture
def factory_app():
    from pmscope.base_wrapper import build_wrapper_app
    return build_wrapper_app(
        name="test-svc",
        version="1.2.3",
        entity_types={"username", "email"},
        watchlist_handler=_sample_handler,
        health_extras=_extras_callback,
    )


def test_factory_produces_fastapi_app(factory_app):
    assert isinstance(factory_app, FastAPI)
    assert factory_app.title == "test-svc"
    assert factory_app.version == "1.2.3"


def test_health_endpoint_basic(factory_app):
    client = TestClient(factory_app)
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "healthy"
    assert body["service"] == "test-svc"
    assert "job_store_backend" in body


def test_health_endpoint_extras(factory_app):
    client = TestClient(factory_app)
    body = client.get("/health").json()
    assert body["extra_field"] == "extra_value"
    assert body["feature_enabled"] is True


def test_watchlist_supported(factory_app):
    client = TestClient(factory_app)
    r = client.post(
        "/api/v1/watchlist/scan",
        json={"entity_type": "username", "entity_value": "johndoe"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["entities"][0]["value"] == "johndoe"
    assert body["attributes"]["handler_called"] is True


def test_watchlist_unsupported(factory_app):
    client = TestClient(factory_app)
    r = client.post(
        "/api/v1/watchlist/scan",
        json={"entity_type": "domain", "entity_value": "example.com"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["metadata"]["skipped"] is True
    assert body["metadata"]["reason"] == "unsupported_type"
    assert body["metadata"]["scan_source"] == "test-svc"


def test_cors_middleware_present(factory_app):
    client = TestClient(factory_app)
    r = client.options(
        "/health",
        headers={
            "Origin": "http://example.com",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert r.headers.get("access-control-allow-origin") is not None


def test_watchlist_handler_error_returns_metadata():
    from pmscope.base_wrapper import build_wrapper_app
    app = build_wrapper_app(
        name="err-svc",
        entity_types={"username"},
        watchlist_handler=_raising_handler,
    )
    client = TestClient(app)
    r = client.post(
        "/api/v1/watchlist/scan",
        json={"entity_type": "username", "entity_value": "x"},
    )
    assert r.status_code == 200
    assert r.json()["metadata"].get("error") is not None


def test_build_wrapper_app_exported():
    from pmscope import build_wrapper_app  # noqa: F401


def test_factory_without_handler_returns_stub():
    from pmscope.base_wrapper import build_wrapper_app
    app = build_wrapper_app(name="no-handler-svc")
    client = TestClient(app)
    r = client.post(
        "/api/v1/watchlist/scan",
        json={"entity_type": "username", "entity_value": "x"},
    )
    assert r.status_code == 200
    assert r.json()["metadata"]["skipped"] is True
