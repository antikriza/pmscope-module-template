"""
Shared intra-service authentication for PM-SCOPE wrapper services.

Protects /api/v1/watchlist/ endpoints with X-Internal-Token header verification.
The API service sends this token when dispatching watchlist scan tasks.

Usage in any FastAPI service:
    from pmscope.service_auth import add_internal_auth_middleware
    add_internal_auth_middleware(app)
"""

import logging
import os
import secrets

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

logger = logging.getLogger(__name__)

# Shared secret — must match INTERNAL_SERVICE_TOKEN in the API service
INTERNAL_SERVICE_TOKEN = os.getenv("INTERNAL_SERVICE_TOKEN", "")

# Paths that require internal auth (prefix match)
PROTECTED_PREFIXES = ("/api/v1/watchlist/",)


class InternalAuthMiddleware(BaseHTTPMiddleware):
    """Middleware that checks X-Internal-Token on protected paths."""

    async def dispatch(self, request: Request, call_next):
        path = request.url.path

        # Only protect specific paths
        if not any(path.startswith(prefix) for prefix in PROTECTED_PREFIXES):
            return await call_next(request)

        # Skip if no token configured (allows graceful rollout)
        if not INTERNAL_SERVICE_TOKEN:
            return await call_next(request)

        token = request.headers.get("X-Internal-Token", "")
        if not token or not secrets.compare_digest(token, INTERNAL_SERVICE_TOKEN):
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid or missing internal service token"},
            )

        return await call_next(request)


def add_internal_auth_middleware(app):
    """Add internal authentication middleware to a FastAPI app."""
    if not INTERNAL_SERVICE_TOKEN:
        logger.warning(
            "INTERNAL_SERVICE_TOKEN is not set — watchlist endpoints are unprotected. "
            "Set INTERNAL_SERVICE_TOKEN in production."
        )
    app.add_middleware(InternalAuthMiddleware)
