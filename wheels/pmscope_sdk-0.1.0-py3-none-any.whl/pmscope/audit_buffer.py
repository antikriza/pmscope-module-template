"""Buffered batch flusher for module audit events.

Producer side: call ``buffer.append(event)`` from any async context.
Consumer side: a single background task awakens on size threshold OR
periodic timeout, POSTs the batch to the configured endpoint, and clears
the buffer. On HTTP failure the batch is dropped (NOT requeued — audit
must never block the producer; structlog WARN records the loss).

Wire format::

    POST {ingest_url}
    Headers: X-Internal-Token: <token>
    Body: {"events": [{"action": str, "timestamp": ISO8601,
                       "payload_hash": "[a-f0-9]{16}", "metadata": {...}}, ...]}
    1 <= events.length <= batch_size (default 100)

PII contract (defense in depth — coordinates with ``services/api/src/routers/audit_ingest.py``):
The producer (this buffer's caller, e.g. ``services/telegram-tools/src/query_bot/handlers/scan.py``)
**must hash** the entity_value with SHA-256 (16-char prefix) before constructing the
``AuditEvent``. The receiving endpoint REJECTS payloads containing a raw ``entity_value``
field. ``metadata`` may carry ``entity_type`` (a class name like ``"username"``) but
never the raw user-supplied value.

Thread-safety: ``asyncio.Queue`` is single-threaded by design. If used from
multiple OS threads, wrap each call site with ``asyncio.run_coroutine_threadsafe``
or invoke ``append`` on the loop owning the buffer.

Test approach: ``test_flush_on_time`` uses the simple
"flush_interval=0.1s + asyncio.sleep(0.3)" approach rather than a deterministic
fake-clock — this keeps the unit tests fast (<1s) and avoids monkeypatching
``time.monotonic`` inside the running event loop.

Phase 5 P3 plan 05-03 — REQ-08a (size flush), REQ-08b (time flush), REQ-08c (drop-on-full WARN).
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, asdict, field
from typing import Optional

import httpx
import structlog

logger = structlog.get_logger("pmscope.audit_buffer")


@dataclass
class AuditEvent:
    """Single audit event — wire-shape consumed by ``/api/v1/audit/ingest``.

    Attributes
    ----------
    action : str
        One of the ``AuditAction`` enum values (e.g. ``"module.query.start"``,
        ``"telegram.bot_query.completed"``). Free-form string for extensibility.
    timestamp : str
        ISO 8601 UTC timestamp produced by the caller.
    payload_hash : str
        16-char hex digest (SHA-256[:16]) of the raw target value. NEVER raw PII.
    metadata : dict
        Free-form metadata. MUST NOT contain ``entity_value`` (the receiver rejects it).
        Typical fields: ``entity_type``, ``user_id``, ``investigation_id``, ``status``.
    """

    action: str
    timestamp: str
    payload_hash: str
    metadata: dict = field(default_factory=dict)


class AuditBuffer:
    """In-memory batched flusher for audit events.

    Lifecycle::

        buffer = AuditBuffer(ingest_url=..., token=...)
        buffer.start()           # spawns background flush task
        buffer.append(event)     # non-blocking enqueue (drops with WARN if full)
        ...
        await buffer.stop()      # drains a final batch and closes the client

    Parameters
    ----------
    ingest_url : str
        Target endpoint, e.g. ``http://api:8000/api/v1/audit/ingest``.
    token : str
        Value of the ``X-Internal-Token`` header sent on every POST.
    batch_size : int, default 100
        Flush when batch reaches this many events (REQ-08a).
    flush_interval : float, default 30.0
        Flush at least every N seconds even if batch is small (REQ-08b).
    max_queue : int, default 1000
        Backpressure cap — once full, ``append`` drops with WARN (REQ-08c).
    client : httpx.AsyncClient, optional
        Pre-configured client (lets tests inject ``MockTransport``). When None,
        the buffer constructs and owns its own ``httpx.AsyncClient(timeout=5.0)``;
        when supplied, the caller owns the client and ``stop()`` will not close it.
    """

    def __init__(
        self,
        ingest_url: str,
        token: str,
        batch_size: int = 100,
        flush_interval: float = 30.0,
        max_queue: int = 1000,
        client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        self._url = ingest_url
        self._token = token
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._queue: asyncio.Queue[AuditEvent] = asyncio.Queue(maxsize=max_queue)
        self._client = client if client is not None else httpx.AsyncClient(timeout=5.0)
        self._owns_client = client is None
        self._task: Optional[asyncio.Task] = None
        self._stop = asyncio.Event()

    def start(self) -> None:
        """Spawn the background flush task. Idempotent."""
        if self._task is None or self._task.done():
            self._stop.clear()
            self._task = asyncio.create_task(self._run(), name="pmscope_audit_flush")

    async def stop(self) -> None:
        """Signal stop, drain a final batch, and (if owned) close the http client.

        The background loop may be parked inside ``asyncio.wait_for(queue.get(), …)``
        with a long timeout when the buffer is idle. Setting the stop event alone
        will not wake it, so we cancel the task and let ``_run`` finish through its
        ``CancelledError`` handler (which still drains any in-flight batch).
        """
        self._stop.set()
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        # Defense in depth: drain anything still on the queue even if the task
        # could not (e.g. it was never started, or cancellation interrupted the
        # internal drain).
        await self._drain_queue()
        if self._owns_client:
            await self._client.aclose()

    async def _drain_queue(self) -> None:
        """Pop everything currently on the queue and flush it as one batch."""
        leftover: list[AuditEvent] = []
        while True:
            try:
                leftover.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        if leftover:
            await self._flush(leftover)

    def append(self, event: AuditEvent) -> None:
        """Non-blocking enqueue. Drops the event with a structlog WARN when the queue is full.

        This is intentionally a sync function so it can be called from synchronous
        producer paths (e.g. middleware, signal handlers) as well as async ones.
        """
        try:
            self._queue.put_nowait(event)
        # graceful drop on full queue
        except asyncio.QueueFull:
            logger.warning(
                "audit_buffer.dropped",
                reason="queue_full",
                action=event.action,
            )

    async def _run(self) -> None:
        """Background flush loop.

        Exits when ``self._stop`` is set OR the task is cancelled by
        :meth:`stop`. On exit, any in-flight batch is flushed as a final POST so
        ``stop()`` truly drains everything before returning.
        """
        last_flush = time.monotonic()
        batch: list[AuditEvent] = []
        try:
            while not self._stop.is_set():
                timeout = max(0.0, self._flush_interval - (time.monotonic() - last_flush))
                try:
                    ev = await asyncio.wait_for(self._queue.get(), timeout=timeout)
                    batch.append(ev)
                except asyncio.TimeoutError:
                    # Time-trigger fired before any new event arrived — fall
                    # through to the size/time check so we still flush a pending
                    # batch.
                    pass

                now = time.monotonic()
                should_flush = (
                    len(batch) >= self._batch_size
                    or (batch and (now - last_flush) >= self._flush_interval)
                )
                if should_flush:
                    await self._flush(batch)
                    batch = []
                    last_flush = now
        except asyncio.CancelledError:
            # stop() cancels this task to wake it from a long wait_for sleep;
            # absorb the cancellation so we can still flush the in-flight batch.
            pass

        # Final shutdown drain — pop anything still on the queue (a producer
        # may have appended between the last get() and the stop signal).
        while True:
            try:
                batch.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        if batch:
            await self._flush(batch)

    async def _flush(self, batch: list[AuditEvent]) -> None:
        """POST a batch to the ingest endpoint. WARN on rejection or transport error."""
        try:
            resp = await self._client.post(
                self._url,
                headers={"X-Internal-Token": self._token},
                json={"events": [asdict(e) for e in batch]},
            )
            if resp.status_code >= 400:
                logger.warning(
                    "audit_buffer.flush_rejected",
                    status=resp.status_code,
                    count=len(batch),
                )
        except Exception as e:  # noqa: BLE001 — audit must never crash the producer
            logger.warning(
                "audit_buffer.flush_failed",
                error=str(e),
                count=len(batch),
            )


__all__ = ["AuditBuffer", "AuditEvent"]
