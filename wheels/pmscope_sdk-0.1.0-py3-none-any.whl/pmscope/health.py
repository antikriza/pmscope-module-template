"""
Shared deep-health helper for PM-SCOPE wrapper services.

Every wrapper (sherlock, email-tools, phone-tools, ...) exposes
`GET /health/deep`. The goal is a uniform response shape across all 28
wrappers so the API aggregator (`services/api/src/routers/health.py`) can
parse them identically.

Usage
-----

    from pmscope.health import build_deep_health

    async def _probe_module() -> tuple[str, str | None]:
        import sherlock  # import-only sanity check
        return ("pass", None)

    @app.get("/health/deep")
    async def deep_health():
        return await build_deep_health("sherlock", [_probe_module])

Envelope shape
--------------

    {
      "service": "sherlock",
      "verdict": "pass" | "warn" | "fail",
      "checked_at": "2026-04-17T12:34:56Z",
      "duration_ms": 42,
      "probes": [
        {"name": "module", "verdict": "pass", "duration_ms": 3, "detail": null}
      ],
      "required_failed": 0,
      "optional_failed": 0
    }

Each probe is an async callable returning a `(verdict, detail)` tuple where
verdict ∈ {"pass", "warn", "fail"}. The helper enforces a per-probe timeout
via `asyncio.wait_for`, and executes probes concurrently via
`asyncio.gather`, so N probes cost max(durations) rather than sum.
"""

from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Iterable, Optional, Tuple, Union

__all__ = ["build_deep_health", "ProbeOutcome"]


#: A probe callable returns either a bare verdict string, or a
#: (verdict, detail) tuple. Both forms are accepted so trivial probes can
#: just `return "pass"` and skip the detail boilerplate.
ProbeOutcome = Union[str, Tuple[str, Optional[str]]]

ProbeFn = Callable[[], Awaitable[ProbeOutcome]]


def _now_iso() -> str:
    """UTC timestamp with trailing Z — matches JSON-Schema/OpenAPI style."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _coerce_outcome(outcome: ProbeOutcome) -> Tuple[str, Optional[str]]:
    """Normalise a probe's return value into `(verdict, detail)`.

    Accepts plain strings for the pass-without-detail case, and tuples of
    length 2 for anything richer. Any other shape is treated as a fail so a
    malformed probe cannot inject garbage into the envelope.
    """

    if isinstance(outcome, str):
        return outcome, None
    if isinstance(outcome, tuple) and len(outcome) == 2:
        verdict, detail = outcome
        return str(verdict), (str(detail) if detail is not None else None)
    return "fail", f"malformed probe return: {outcome!r}"


def _normalise_verdict(v: str) -> str:
    """Map unknown verdicts to `fail`. Keeps the contract closed."""
    return v if v in ("pass", "warn", "fail") else "fail"


async def _run_single(
    name: str,
    fn: ProbeFn,
    timeout: float,
) -> dict:
    """Run one probe, enforcing its timeout and capturing exceptions.

    Returns a dict in the envelope format. Never raises — a misbehaving
    probe cannot take down the health endpoint it's trying to serve.
    """

    started = time.perf_counter()
    try:
        raw = await asyncio.wait_for(fn(), timeout=timeout)
        verdict, detail = _coerce_outcome(raw)
        verdict = _normalise_verdict(verdict)
    except asyncio.TimeoutError:
        duration_ms = int((time.perf_counter() - started) * 1000)
        return {
            "name": name,
            "verdict": "fail",
            "duration_ms": duration_ms,
            "detail": f"timeout after {int(timeout * 1000)}ms",
        }
    except Exception as exc:  # noqa: BLE001 — probes must never leak
        duration_ms = int((time.perf_counter() - started) * 1000)
        return {
            "name": name,
            "verdict": "fail",
            "duration_ms": duration_ms,
            "detail": f"{type(exc).__name__}: {exc}",
        }

    duration_ms = int((time.perf_counter() - started) * 1000)
    return {
        "name": name,
        "verdict": verdict,
        "duration_ms": duration_ms,
        "detail": detail,
    }


def _probe_name(fn: ProbeFn, index: int) -> str:
    """Derive a stable probe name from the callable for the response envelope."""
    return getattr(fn, "__name__", None) or f"probe_{index}"


async def build_deep_health(
    service_name: str,
    probes: Iterable[ProbeFn],
    timeout: float = 1.5,
) -> dict[str, Any]:
    """Run `probes` in parallel and return a standard deep-health envelope.

    Args:
        service_name: Wrapper name (e.g. `"sherlock"`). Appears verbatim as
            `service` in the envelope so the API aggregator can correlate.
        probes: Iterable of async callables. Each is invoked with no args.
        timeout: Per-probe budget in seconds. Applied uniformly; callers
            that need mixed timeouts should wrap probes in a closure or
            provide two separate routes.

    Returns:
        The envelope described at the top of this module. Verdict rules:

            * `pass` — every probe returned `pass`.
            * `warn` — at least one probe returned `warn` (and none failed),
              or the probe list was empty (nothing to check is suspect).
            * `fail` — any probe returned `fail`.
    """

    started = time.perf_counter()

    probe_list = list(probes)

    if not probe_list:
        return {
            "service": service_name,
            "verdict": "warn",
            "checked_at": _now_iso(),
            "duration_ms": 0,
            "probes": [],
            "required_failed": 0,
            "optional_failed": 0,
            "detail": "no probes registered",
        }

    tasks = [
        _run_single(_probe_name(fn, idx), fn, timeout)
        for idx, fn in enumerate(probe_list)
    ]
    results = await asyncio.gather(*tasks)

    failed = sum(1 for r in results if r["verdict"] == "fail")
    warned = sum(1 for r in results if r["verdict"] == "warn")

    if failed:
        verdict = "fail"
    elif warned:
        verdict = "warn"
    else:
        verdict = "pass"

    duration_ms = int((time.perf_counter() - started) * 1000)

    return {
        "service": service_name,
        "verdict": verdict,
        "checked_at": _now_iso(),
        "duration_ms": duration_ms,
        "probes": results,
        # All sub-probes are treated as required at the wrapper layer — the
        # API aggregator decides whether the whole wrapper is optional.
        "required_failed": failed,
        "optional_failed": 0,
    }
