"""PM-SCOPE wrapper factory.

Replaces the ~80-line boilerplate every wrapper's main.py copies:
    - structlog.configure
    - FastAPI instantiation with CORS middleware
    - service_auth middleware
    - /health endpoint
    - /api/v1/watchlist/scan endpoint with entity_type guard

Usage (pilot in services/trade-tools/src/main.py):

    from pmscope.base_wrapper import build_wrapper_app

    async def _handler(entity_type: str, entity_value: str) -> dict:
        ...
        return {"entities": [...], "attributes": {...}, "mentions": [...], "metadata": {...}}

    app = build_wrapper_app(
        name="trade-tools",
        version="1.0.0",
        entity_types={"company", "person"},
        redis_url=settings.REDIS_URL,
        redis_prefix="trade",
        watchlist_handler=_handler,
    )

The factory does NOT own analyze/history/stats endpoints, DB engines,
Prometheus counters, or /health/deep — those stay service-specific.
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator, Awaitable, Callable, FrozenSet, Optional

import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field


logger = logging.getLogger("pmscope.base_wrapper")


class WatchlistScanRequest(BaseModel):
    entity_type: str
    entity_value: str


class WatchlistScanResponse(BaseModel):
    entities: list[dict] = Field(default_factory=list)
    attributes: dict[str, Any] = Field(default_factory=dict)
    mentions: list[dict] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


WatchlistHandler = Callable[[str, str], Awaitable[dict]]
HealthExtrasFn = Callable[[], Awaitable[dict]]
LifespanHook = Callable[[FastAPI], Awaitable[None]]


def _configure_structlog() -> None:
    structlog.configure(
        processors=[
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.JSONRenderer(),
        ]
    )


def _init_job_store(
    redis_url: Optional[str], prefix: Optional[str]
) -> tuple[Any, str]:
    if not redis_url or not prefix:
        return None, "none"
    try:
        from pmscope.redis_job_store import create_job_store
        store = create_job_store(redis_url=redis_url, prefix=prefix)
        return store, type(store).__name__
    except ImportError:
        return None, "unavailable"
    except Exception as e:
        logger.warning("job_store_init_failed: %s", e)
        return None, "failed"


def build_wrapper_app(
    name: str,
    version: str = "1.0.0",
    description: Optional[str] = None,
    entity_types: Optional[set[str] | FrozenSet[str]] = None,
    redis_url: Optional[str] = None,
    redis_prefix: Optional[str] = None,
    watchlist_handler: Optional[WatchlistHandler] = None,
    health_extras: Optional[HealthExtrasFn] = None,
    lifespan_setup: Optional[LifespanHook] = None,
    lifespan_teardown: Optional[LifespanHook] = None,
) -> FastAPI:
    _configure_structlog()
    log = structlog.get_logger()

    supported_types: frozenset = frozenset(entity_types or set())
    job_store, backend_name = _init_job_store(redis_url, redis_prefix)

    @asynccontextmanager
    async def _lifespan(app: FastAPI) -> AsyncGenerator:
        log.info("wrapper.startup", service=name, version=version, job_store_backend=backend_name)
        if lifespan_setup:
            try:
                await lifespan_setup(app)
            except Exception as e:
                log.error("wrapper.lifespan_setup.failed", service=name, error=str(e))
                raise
        yield
        log.info("wrapper.shutdown", service=name)
        if lifespan_teardown:
            try:
                await lifespan_teardown(app)
            except Exception as e:
                log.warning("wrapper.lifespan_teardown.failed", service=name, error=str(e))

    app = FastAPI(
        title=name,
        description=description or f"PM-SCOPE {name} wrapper service",
        version=version,
        lifespan=_lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    try:
        from pmscope.service_auth import add_internal_auth_middleware
        add_internal_auth_middleware(app)
    except ImportError:
        pass
    except Exception as e:
        log.warning("wrapper.service_auth.init_failed", error=str(e))

    app.state.job_store = job_store
    app.state.job_store_backend = backend_name

    @app.get("/health")
    async def _health() -> dict:
        body: dict[str, Any] = {
            "status": "healthy",
            "service": name,
            "job_store_backend": backend_name,
        }
        if health_extras:
            try:
                extras = await health_extras()
                if isinstance(extras, dict):
                    body.update(extras)
            except Exception as e:
                body["health_extras_error"] = str(e)
        return body

    @app.post("/api/v1/watchlist/scan", response_model=WatchlistScanResponse)
    async def _watchlist_scan(req: WatchlistScanRequest) -> WatchlistScanResponse:
        if req.entity_type not in supported_types:
            return WatchlistScanResponse(
                metadata={
                    "scan_source": name,
                    "skipped": True,
                    "reason": "unsupported_type",
                    "entity_type": req.entity_type,
                }
            )
        if watchlist_handler is None:
            return WatchlistScanResponse(
                metadata={
                    "scan_source": name,
                    "skipped": True,
                    "reason": "no_handler_configured",
                }
            )
        try:
            result = await watchlist_handler(req.entity_type, req.entity_value)
        except Exception as e:
            log.warning(
                "wrapper.watchlist.handler_failed",
                service=name,
                entity_type=req.entity_type,
                error=str(e),
            )
            return WatchlistScanResponse(
                metadata={
                    "scan_source": name,
                    "error": f"{type(e).__name__}: {e}",
                }
            )
        if not isinstance(result, dict):
            return WatchlistScanResponse(
                metadata={"scan_source": name, "error": "handler returned non-dict"}
            )
        return WatchlistScanResponse(
            entities=result.get("entities") or [],
            attributes=result.get("attributes") or {},
            mentions=result.get("mentions") or [],
            metadata={**(result.get("metadata") or {}), "scan_source": name},
        )

    return app


__all__ = ["build_wrapper_app", "WatchlistScanRequest", "WatchlistScanResponse"]
